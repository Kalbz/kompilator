public class Factorial{
    public static void main(String[] a){
    }
}

class Element {
    public boolean Init(){
        int test = v_Age ;  
        if(if(true)){
        }
    }
}
